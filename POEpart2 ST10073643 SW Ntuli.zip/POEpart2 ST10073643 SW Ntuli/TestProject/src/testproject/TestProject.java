/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testproject;

/**
 *
 * @author Admin
 */
public class TestProject
{ 
    String outcome ="Hello TestMethod";
    
    public String TestMethod ()
    { 
        return outcome;
    }        
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String rt;
        TestProject tm = new TestProject ();
        rt= tm.TestMethod(); 
        
        System.out.println(rt);
                
        // TODO code application logic here
    }
    
}
