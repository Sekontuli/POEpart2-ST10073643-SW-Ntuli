/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package easykanban;

import org.junit.After;
import org.junit.Test;

/**
 *
 * @author Admin
 */
public class TaskTest {
    
    public TaskTest() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testCheckTaskDescription() {
    }

    @Test
    public void testCreateTaskID() {
    }

    @Test
    public void testPrintTaskDetails() {
    }

    @Test
    public void testReturnTotalHours() {
    }
    
}
