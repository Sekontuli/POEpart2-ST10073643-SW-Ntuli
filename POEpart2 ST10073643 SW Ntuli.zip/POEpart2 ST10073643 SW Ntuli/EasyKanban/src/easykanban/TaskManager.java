  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package easykanban;

import java.util.ArrayList;

 

public class TaskManager {

   private final ArrayList<String> developers;

   private final ArrayList<String> taskNames;

   private final ArrayList<Integer> taskIds;

   private final ArrayList<Integer> taskDurations;

   private final ArrayList<String> taskStatuses;

   private int taskCounter;

 

   public TaskManager() {

       developers = new ArrayList<>();

       taskNames = new ArrayList<>();

       taskIds = new ArrayList<>();

       taskDurations = new ArrayList<>();

       taskStatuses = new ArrayList<>();

       taskCounter = 1; // Unique Task IDs

   }

 

   public void addTask(String developer, String taskName, int taskDuration, String taskStatus) {

       developers.add(developer);

       taskNames.add(taskName);

       taskIds.add(taskCounter++);

       taskDurations.add(taskDuration);

       taskStatuses.add(taskStatus);

   }

 

   public ArrayList<String[]> displayDoneTasks() {

       ArrayList<String[]> doneTasks = new ArrayList<>();

       for (int i = 0; i < taskStatuses.size(); i++) {

           if (taskStatuses.get(i).equalsIgnoreCase("done")) {

               doneTasks.add(new String[]{developers.get(i), taskNames.get(i), String.valueOf(taskDurations.get(i))});

           }

       }

       return doneTasks;

   }

 

   public String longestDuration() {

       int maxDuration = 0;

       String developer = "";

       for (int i = 0; i < taskDurations.size(); i++) {

           if (taskDurations.get(i) > maxDuration) {

               maxDuration = taskDurations.get(i);

               developer = developers.get(i);

           }

       }

       return developer + ", " + maxDuration;

   }

 

   public String searchTask(String taskName) {

       int index = taskNames.indexOf(taskName);

       if (index != -1) {

           return taskNames.get(index) + ", " + developers.get(index) + ", " + taskStatuses.get(index);

       }

       return "Task not found.";

   }

 

   public ArrayList<String[]> tasksByDeveloper(String developer) {

       ArrayList<String[]> tasks = new ArrayList<>();

       for (int i = 0; i < developers.size(); i++) {

           if (developers.get(i).equals(developer)) {

               tasks.add(new String[]{taskNames.get(i), taskStatuses.get(i)});

           }

       }

       return tasks;

   }

 

   public String deleteTask(String taskName) {

       int index = taskNames.indexOf(taskName);

       if (index != -1) {

           developers.remove(index);

           taskNames.remove(index);

           taskIds.remove(index);

           taskDurations.remove(index);

           taskStatuses.remove(index);

           return "Entry '" + taskName + "' successfully deleted.";

       }

       return "Task not found.";

   }

 

   public String displayReport() 

   {

       StringBuilder report = new StringBuilder();

       for (int i = 0; i < developers.size(); i++) {

           report.append("Developer: ").append(developers.get(i))

                 .append(", Task: ").append(taskNames.get(i))

                 .append(", Duration: ").append(taskDurations.get(i))

                 .append(", Status: ").append(taskStatuses.get(i)).append("\n");

       }

       return report.toString();

   }

   

   

   public static void main(String[] args) {

       TaskManager taskManager = new TaskManager();

 

       // Adding test data

       taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");

       taskManager.addTask("Edward Harrison", "Create Add Features", 8, "Doing");

       taskManager.addTask("Samantha Paulson", "Create Reports", 2, "Done");

       taskManager.addTask("Glenda Oberholzer", "Add Arrays", 11, "To Do");

 

       // Display done tasks

       System.out.println("Done Tasks: " + taskManager.displayDoneTasks());

 

       // Longest duration

       System.out.println("Longest Duration Task: " + taskManager.longestDuration());

 

       // Search for a task

       System.out.println("Search Task: " + taskManager.searchTask("Create Login"));

 

       // Tasks by developer

       System.out.println("Tasks assigned to Samantha Paulson: " + taskManager.tasksByDeveloper("Samantha Paulson"));

 

       // Delete a task

       System.out.println(taskManager.deleteTask("Create Reports"));

 

       // Display report

       System.out.println("Task Report: \n" + taskManager.displayReport());

   }

   

   

}
